package com.cm.opensdk.model;

/**
 * Author: Patter
 * Data:   2018/3/15
 * Email: 401219741@qq.com
 */

public class ShareImageReq extends BaseReq{
    private String imageUrl;

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
