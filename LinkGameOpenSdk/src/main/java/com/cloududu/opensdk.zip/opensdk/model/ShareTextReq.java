package com.cm.opensdk.model;

/**
 * Author: Patter
 * Data:   2018/3/15
 * Email: 401219741@qq.com
 */

public class ShareTextReq extends BaseReq {
    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
