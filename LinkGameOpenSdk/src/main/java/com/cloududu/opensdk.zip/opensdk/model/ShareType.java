package com.cm.opensdk.model;

/**
 * Author: Patter
 * Data:   2018/3/13
 * Email: 401219741@qq.com
 */

public class ShareType {
    public static int TEXT = 1;
    public static int IMAGE = 2;
    public static int URL = 3;
}
